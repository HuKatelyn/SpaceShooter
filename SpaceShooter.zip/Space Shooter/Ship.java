import java.awt.Color;
import java.awt.Graphics;
public class Ship {
    private int x;
    private int y;
    private Color grey;
    private Color green;

    public Ship(int x, int y){
        this.x = x;
        this.y = y;
        grey = new Color(101, 106,115);
        green = new Color(58, 235, 52);
    }

    public void drawMe(Graphics g){
        g.setColor(grey);
        g.fillRect(x,y, 100, 10);
        g.fillRect(x+10, y-10, 80, 10);
        g.fillRect(x+10, y+10, 80, 10);
        g.fillRect(x+20, y+20, 40, 10);
        g.fillRect(x+20, y-20, 40, 10);
        g.fillRect(x+10, y-30, 60, 10);
        g.fillRect(x+10, y+30, 60, 10);
        g.fillRect(x+10, y+40, 40, 10);
        g.fillRect(x+10, y-40, 40, 10);
        g.fillRect(x+10, y-50, 50, 10);
        g.fillRect(x+10, y+50, 50, 10);
        g.setColor(green);
        g.fillRect(x+60, y, 20, 10);
    }

    public void moveUp(){
        y -= 20;
    }

    public void moveDown(){
        y += 20;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y-50;
    }

    public int getWidth(){
        return 100;
    }

    public int getHeight(){
        return 110;
    }
}
