import java.awt.Color;
import java.awt.Graphics;
public class Fish {
    private int x;
    private int y;
    private Color black;
    private Color orange;

    public Fish(int x, int y){
        this.x = x;
        this.y = y;
        black = new Color(0,0,0);
        orange = new Color(247, 147, 7);
    }

    public void drawMe(Graphics g){
        g.setColor(orange);
        g.fillOval(x+25, y+10, 50, 30);
        g.fillPolygon(new int[] {x+70, x+90, x+90}, new int[] {y+25, y, y+50}, 3);

        g.setColor(black);
        g.fillOval(x+32, y+15, 10, 10);
    }

    public void move(){
        x--;
        
        if(x < -100){
            x = 800;
            y = (int)(Math.random()*550);
        }
    }
}
