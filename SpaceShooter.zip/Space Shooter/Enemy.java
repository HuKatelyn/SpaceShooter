import java.awt.Color;
import java.awt.Graphics;

public class Enemy{
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private Color green;
    private Color darkGreen;
    private Color lightGreen;
    private Color black;
    private boolean visible;

    private int yDirection;
    private int count;
	
	public Enemy(int x, int y){
		
		this.x = x;
		this.y = y;
		
		width = 90;
		height = 90;
		
		green = new Color(119, 235, 52);
        black = new Color(0,0,0);
        darkGreen = new Color(101, 199, 44);
        lightGreen = new Color(167, 237, 126);
		visible = true;
			
        count = 0;
        yDirection = 1;
	}
	

	public void drawMe(Graphics g){
	
        if(visible == true){
            //alien head
            g.setColor(green);
		    g.fillRect(x+20,y,width-40,height-80);
            g.fillRect(x+10,y+10,width-20,height-80);
            g.fillRect(x,y+20,width,height-80);
            g.fillRect(x,y+30,width,height-80);
            g.fillRect(x,y+40,width,height-80);
            g.fillRect(x,y+50,width,height-80);
            g.fillRect(x+10,y+60,width-20,height-80);
            g.fillRect(x+20,y+70,width-40,height-80);
            g.fillRect(x+30,y+80,width-60,height-80);
            
            //eyes
            g.setColor(black);
            g.fillRect(x+10,y+30,width-70,height-80);
            g.fillRect(x+60,y+30,width-70,height-80);
            g.fillRect(x+10,y+40,width-60,height-80);
            g.fillRect(x+50,y+40,width-60,height-80);
            g.fillRect(x+20,y+50,width-70,height-80);
            g.fillRect(x+50,y+50,width-70,height-80);

            //shading
            g.setColor(darkGreen);
            g.fillRect(x,y+20,width-80,height-50);
            g.fillRect(x+10,y+50,width-80,height-70);
            g.fillRect(x+20,y+70,width-80,height-80);
            g.fillRect(x+30,y+80,width-80,height-80);

            g.setColor(lightGreen);
            g.fillRect(x+60,y,width-80,height-80);
            g.fillRect(x+70,y+10,width-80,height-80);
            g.fillRect(x+80,y+20,width-80,height-80);
        }

	}
	
    public void disappear(){
        visible = false;
    }

    public boolean getVisible(){
        return visible;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public int getWidth(){
        return width;
    }

    public int getHeight(){
        return height;
    }
	
	public void move(){
        x--;
        count++;

        if(yDirection == 1){
            y--;
        } else if(yDirection == 2){
            y++;
        }

        if(count == 200){
            yDirection = (int) (Math.random()*3);
            count = 0;
        }

        if(y == 0){
            y++;
        }

        if(y == 510){
            y--;
        }
    }

    public void reset(){
        x = 650;
        visible = true;
    }

    public boolean checkCollision(Ship s){
        boolean collision = false;

        if(visible == true){
            int eX = x;
            int eY = y;
            int eWidth = width;
            int eHeight = height;
            int tX = s.getX();
            int tY = s.getY();
            int tWidth = s.getWidth();
            int tHeight = s.getHeight();

            if( eX+eWidth >= tX && eX <= tX + tWidth  &&  eY+eHeight >= tY && eY <= tY + tHeight ){
                System.out.println("Collision");	
                visible = false;
                collision = true;	
            }
        }
        return collision; 

    }
}

