import java.awt.Color;
import java.awt.Graphics;

public class Boss{
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private Color green;
    private Color darkGreen;
    private Color lightGreen;
    private Color black;
    private Color white;
    private boolean visible;

    private int yDirection;
    private int count;
	
	public Boss(int x, int y){
		
		this.x = x;
		this.y = y;
		
		width = 100;
		height = 100;
		
		green = new Color(119, 235, 52);
        black = new Color(0,0,0);
        darkGreen = new Color(101, 199, 44);
        lightGreen = new Color(167, 237, 126);
        white = new Color(255, 255, 255);
		visible = true;
			
        count = 0;
        yDirection = 1;
	}
	

	public void drawMe(Graphics g){
	
        if(visible == true){
            //eyeball
            g.setColor(white);
            g.fillOval(x, y, width, height);

            //iris
            g.setColor(darkGreen);
            g.fillOval(x+25, y+25, width-50, height-50);

            //pupil
            g.setColor(black);
            g.fillOval(x+40, y+40, width-80, height-80);
        }

	}
	
    public void disappear(){
        visible = false;
    }

    public boolean getVisible(){
        return visible;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public int getWidth(){
        return width;
    }

    public int getHeight(){
        return height;
    }
	
	public void move(){
        x--;
        count++;

        if(yDirection == 1){
            y--;
        } else if(yDirection == 2){
            y++;
        }

        if(count == 50){
            yDirection = (int) (Math.random()*3);
            count = 0;
        }

        if(y == 0){
            y++;
        }

        if(y == 500){
            y--;
        }
    }

    public void reset(){
        x = 650;
        visible = true;
    }

    public boolean checkCollision(Ship s){
    boolean collision = false;
        if(visible == true){
            int eX = x;
            int eY = y;
            int eWidth = width;
            int eHeight = height;
            int tX = s.getX();
            int tY = s.getY();
            int tWidth = s.getWidth();
            int tHeight = s.getHeight();

            if( eX+eWidth >= tX && eX <= tX + tWidth  &&  eY+eHeight >= tY && eY <= tY + tHeight ){
                System.out.println("Collision");	
                visible = false;
                collision = true;	
            }
        }
        return collision; 

    }
}


