import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.Font;

public class Screen extends JPanel implements KeyListener{

    private Projectile p1;
    private Ship s1;
    private Fish[] fishArray;
    private Star[] starArray;
    private Color black;
    private Color blue;
    private Color purple;
    private Color white;
    private Color yellow;
    private Enemy[] enemyArray;
    private Enemy2[] enemy2Array;
    private int level;
    private int lives;
    private Boss boss;
    private int collisions;


    public Screen() {

        lives = 3;

        level = 1;

        enemyArray = new Enemy[3];
        for (int i = 0; i < enemyArray.length; i++){
            int x = 650;
            int y = (int)(Math.random()*511);
            enemyArray[i] = new Enemy(x, y);
        }

        enemy2Array = new Enemy2[5];
        for (int i = 0; i < enemy2Array.length; i++){
            int x = 600;
            int y = (int)(Math.random()*461);
            enemy2Array[i] = new Enemy2(x, y);
        }

        starArray = new Star[100];
        for(int i = 0; i < starArray.length; i++){
            starArray[i] = new Star();
        }

        fishArray = new Fish[5];
        for (int i = 0; i < fishArray.length; i++){
            int x = (int)(Math.random()*700);
            int y = (int)(Math.random()*550);
            fishArray[i] = new Fish(x, y);
        }

        black = new Color(0,0,0);
        blue = new Color(48, 112, 176);
        purple = new Color(63, 35, 153);
        white = new Color(255, 255, 255);
        yellow = new Color(250, 213, 2);

        s1 = new Ship(50, 300);
        p1 = new Projectile(50, 300);
        boss = new Boss(600, 250);

        setFocusable(true);
        addKeyListener(this);

    }

    public Dimension getPreferredSize() {
        //Sets the size of the panel
        return new Dimension(800, 600);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if(level == 1){
            //draw background
            g.setColor(black);
            g.fillRect(0,0,800,600);

            //draw each star in the array
            g.setColor(white);
            for(int i = 0; i < starArray.length; i++){
                starArray[i].drawMe(g);
            }

            //Draw ship
            s1.drawMe(g);

            //Draw Projectile
            p1.drawMe(g);

            //Draw each enemy in the enemy array
            for(int i = 0; i < enemyArray.length; i++){
                enemyArray[i].drawMe(g);
            }
        }

        if(level == 2){
            g.setColor(blue);
            g.fillRect(0,0,800,600);

            //Draw each fish in the fish array
            for(int i = 0; i < fishArray.length; i++){
                fishArray[i].drawMe(g);
            }

            //Draw ship
            s1.drawMe(g);

            //Draw Projectile
            p1.drawMe(g);

            //Draw each enemy in the enemy array
            for(int i = 0; i < enemy2Array.length; i++){
                enemy2Array[i].drawMe(g);
            }
        }

        if(level == 3){
            //draw background
            g.setColor(purple);
            g.fillRect(0,0,800,600);

            //draw each star in the array
            g.setColor(yellow);
            for(int i = 0; i < starArray.length; i++){
                starArray[i].drawMe(g);
            }

            //Draw ship
            s1.drawMe(g);

            //Draw Projectile
            p1.drawMe(g);

            //Draw boss
            boss.drawMe(g);
        }

        //Write the level number
        if(level < 4){
            Font font = new Font("Arial", Font.PLAIN, 50);  //50 represents the font size
            g.setFont(font);
            g.setColor(Color.red);
            g.drawString("Lives: " + lives, 250, 50);
            g.drawString("Level " + level, 50, 50);
        }

        //make end screen
        if(level >= 4){
            Font font = new Font("Arial", Font.PLAIN, 75);  //50 represents the font size
            g.setFont(font);
            g.setColor(Color.black);
            g.drawString("Congratulations,", 125, 250);
            g.drawString("You Won!", 225, 350);
        }
    }


    public void animate() {

        while (true) {

            if(level == 1){
                //move each star in the array
                for(int i = 0; i < starArray.length; i++){
                    starArray[i].move();
                }

                //move the projectile
                p1.moveRight();

                int total = 0;
                for(int i = 0; i < enemyArray.length; i++){
                    if(enemyArray[i].getVisible() == false){
                        total++;
                    }
        
                }
                
                if(total == 3){
                    level = 2;
                }
            
                for(int i = 0; i < enemyArray.length; i++){
                    if(enemyArray[i].getX() < -90){
                        lives--;
                        //go through all the enemies and reset the x value
                        for(int j = 0; j < enemyArray.length; j++){
                            enemyArray[j].reset();
                        }
                        p1.reset(50);
                        
                    } 
                }

                for(int i = 0; i < enemyArray.length ; i++){
                    if(enemyArray[i].checkCollision(s1) == true){
                        lives--;
                        for(int j = 0; j < enemyArray.length; j++){
                            enemyArray[j].reset();
                        }
                        p1.reset(50);
                    }
                }
                //move the each enemy
                for(int i = 0; i < enemyArray.length; i++){
                    enemyArray[i].move();
                }

                //check collision between each enemy in the enemyArray
                for(int i = 0; i < enemyArray.length ; i++){
                    p1.checkCollision(enemyArray[i]);
                }

                //reset level if lives equals 0
                if(lives == 0){
                    lives = 3;
                    level = 1;
                    for(int i = 0; i < enemyArray.length; i++){
                        enemyArray[i].reset();
                    }
                    p1.reset(50);
                }
            }

            if(level == 2){

                //move each fish in the array
                for(int i = 0; i < fishArray.length; i++){
                    fishArray[i].move();
                }
                
                //move the projectile
                p1.moveRight();

                //if 5 enemies are not visible, level increases
                int total2 = 0;
                for(int i = 0; i < enemy2Array.length; i++){
                    if(enemy2Array[i].getVisible() == false){
                        total2++;
                    }
        
                }
                
                if(total2 == 5){
                    level = 3;
                }

                //if enemies go past ship, reset location
                for(int i = 0; i < enemy2Array.length; i++){
                    if(enemy2Array[i].getX() < -190){
                        lives--;
                        //go through all the enemies and reset the x value
                        for(int j = 0; j < enemy2Array.length; j++){
                            enemy2Array[j].reset();
                        }
                        p1.reset(50);
                        
                    } 
                }

                //if enemies collide with ship, reset location
                for(int i = 0; i < enemy2Array.length ; i++){
                    if(enemy2Array[i].checkCollision(s1) == true){
                        lives--;
                        for(int j = 0; j < enemy2Array.length; j++){
                            enemy2Array[j].reset();
                        }
                        p1.reset(50);
                    }
                }

                //move each enemy
                for(int i = 0; i < enemy2Array.length; i++){
                    enemy2Array[i].move();
                }

                //check collision between each enemy in the enemyArray
                for(int i = 0; i < enemy2Array.length ; i++){
                    p1.checkCollision2(enemy2Array[i]);
                }

                //reset level if lives equals 0
                if(lives == 0){
                    lives = 3;
                    level = 1;
                    for(int i = 0; i < enemyArray.length; i++){
                        enemyArray[i].reset();
                    }
                    p1.reset(50);
                }
            }

            if(level == 3){
                //move each star in the array
                for(int i = 0; i < starArray.length; i++){
                    starArray[i].move();
                }

                //move the projectile
                p1.moveRight();
                
                //if boss goes past ship, reset location
                if(boss.getX() < -100){
                    lives--;
                        
                    boss.reset();

                    p1.reset(50);
                        
                } 

                //if boss collides with ship, reset location
                if(boss.checkCollision(s1) == true){
                    lives--;
                    boss.reset();
                    p1.reset(50);
                }
                
                //move the boss
                boss.move();

                //check collision between each enemy in the enemyArray
                p1.checkCollision3(boss);

                collisions = p1.getHit();

                if(collisions == 3){
                    level++;
                    boss.disappear();
                    System.out.println(collisions);
                }

                //reset level if lives equals 0
                if(lives == 0){
                    lives = 3;
                    level = 1;
                    for(int i = 0; i < enemyArray.length; i++){
                        enemyArray[i].reset();
                    }
                    p1.reset(50);
                }
            }

            //wait for .01 second
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }

            //repaint the graphics drawn
            repaint();
        }

    }

    public void keyPressed(KeyEvent e){
        System.out.println(e.getKeyCode());
        
        if(e.getKeyCode() == 38){ //up arrow
            //move the ship up
            s1.moveUp();
        } else if(e.getKeyCode() == 40){ //down arrow
            //move the ship down
            s1.moveDown();
        } else if(e.getKeyCode() == 32){
            //make the projectile go to where the ship is
            //get the position of the ship
            int shipX = s1.getX();
            int shipY = s1.getY();
            //update position of the projectile to that
            p1.setPosition(shipX, shipY);

            //the projectile will appear (change visible in projectile to true)
            p1.fire();
        } else if(e.getKeyCode() == 79){
            level++;
        }
        
    }
    public void keyReleased(KeyEvent e){}
    public void keyTyped(KeyEvent e){}

}