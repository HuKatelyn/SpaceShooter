import java.awt.Color;
import java.awt.Graphics;

public class Projectile{
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private Color red;
    private boolean visible;
    private int hit;
	
	public Projectile(int x, int y){
		
		this.x = x;
		this.y = y;
		
		this.width = 10;
		this.height = 10;
		
		this.red = new Color(255,0,0);
        this.visible = false;

        hit = 0;
	}
	

	public void drawMe(Graphics g){
		
        if(visible == true){
            g.setColor(red);
		    g.fillOval(x,y,width,height);
		
        }
	}

    public void moveRight(){
        if(visible == true){
            x += 3;
        }
        if(x > 800){
            x = 150;
            visible = false;
        }
    }

    public void fire(){
        visible = true;
    }

    public void setPosition(int x, int y){
        if(visible == false){
            this.x = x+100;
            this.y = y+50;
        }
    }

    public void checkCollision(Enemy e){

        if(e.getVisible() == true){
            int pX = x;
            int pY = y;
            int pWidth = width;
            int pHeight = height;
            int tX = e.getX();
            int tY = e.getY();
            int tWidth = e.getWidth();
            int tHeight = e.getHeight();

            if( pX+pWidth >= tX && pX <= tX + tWidth  &&  pY+pHeight >= tY && pY <= tY + tHeight ){
                System.out.println("Collision");	
                visible = false;
                e.disappear();	
                
            }
        }

    }

    public void checkCollision2(Enemy2 e2){

        if(e2.getVisible() == true){
            int pX = x;
            int pY = y;
            int pWidth = width;
            int pHeight = height;
            int tX = e2.getX();
            int tY = e2.getY();
            int tWidth = e2.getWidth();
            int tHeight = e2.getHeight();

            if( pX+pWidth >= tX && pX <= tX + tWidth  &&  pY+pHeight >= tY && pY <= tY + tHeight ){
                System.out.println("Collision");	
                visible = false;
                e2.disappear();	
                
            }
        }

    }

    public void checkCollision3(Boss e3){
        if(e3.getVisible() == true){
            int pX = x;
            int pY = y;
            int pWidth = width;
            int pHeight = height;
            int tX = e3.getX();
            int tY = e3.getY();
            int tWidth = e3.getWidth();
            int tHeight = e3.getHeight();

            if( pX+pWidth >= tX && pX <= tX + tWidth  &&  pY+pHeight >= tY && pY <= tY + tHeight ){
                System.out.println("Collision");	
                visible = false;
                x = 50;
                hit++;
            }
        }

    }

    public int getHit(){
        return hit;
    }

    public void reset(int x){
        this.x = x;
        visible = false;
        hit = 0;
    }
}