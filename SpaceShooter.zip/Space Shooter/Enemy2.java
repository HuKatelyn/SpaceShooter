import java.awt.Color;
import java.awt.Graphics;

public class Enemy2{
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private Color gold;
    private Color orange;
    private Color red;
    private Color tan;
    private Color yellow;
    private Color darkBlue;
    private Color blue;
    private Color teal;
    private boolean visible;

    private int yDirection;
    private int count;
	
	public Enemy2(int x, int y){
		
		this.x = x;
		this.y = y;
		
		width = 190;
		height = 160;
		
		gold = new Color(227, 150, 50);
        orange = new Color(222, 92, 33);
        red = new Color(150, 49, 18);
        tan = new Color(222, 204, 160);
        yellow = new Color(247, 232, 99);
        darkBlue = new Color(39, 112, 230);
        blue = new Color(49, 162, 232);
        teal = new Color(102, 222, 222);
		visible = true;
			
        count = 0;
        yDirection = 1;
	}
	

	public void drawMe(Graphics g){
	
        if(visible == true){
            //submarine body
            g.setColor(gold);
            g.fillRect(x,y,width-40,height-120);
            g.fillRect(x+10,y-10,width-60,height-150);
            g.fillRect(x+160,y,width-170,height-120);
            g.fillRect(x+60,y-40,width-160,height-140);
            g.fillRect(x+80,y-80,width-180,height-140);
            g.fillRect(x+70,y-80,width-180,height-150);

            g.setColor(orange);
            g.fillRect(x+20,y+40,width-60,height-140);
            g.fillRect(x+150,y+10,width-180,height-140);
            g.fillRect(x+160,y+40,width-170,height-130);
            g.fillRect(x+180,y+20,width-180,height-150);
            g.fillRect(x+60,y-20,width-160,height-150);
            g.fillRect(x+90,y-40,width-170,height-130);
            g.fillRect(x+80,y-60,width-180,height-140);

            g.setColor(red);
            g.fillRect(x,y+50,width-170,height-150);
            g.fillRect(x+10,y+60,width-50,height-150);
            g.fillRect(x+20,y+70,width-70,height-150);
            g.fillRect(x+140,y+50,width-170,height-150);
            g.fillRect(x+150,y+30,width-180,height-140);
            g.fillRect(x+180,y+30,width-180,height-140);
            g.fillRect(x+90,y-20,width-180,height-150);

            //windows
            g.setColor(blue);
            g.fillRect(x+10,y,width-160,height-120);

            g.setColor(darkBlue);
            g.fillRect(x+80,y+20,width-170, height-140);

            g.setColor(blue);
            g.fillRect(x+80,y+20,width-180, height-150);

            g.setColor(teal);
            g.fillRect(x+10,y,width-180, height-150);

            g.setColor(darkBlue);
            g.fillRect(x,y,width-180, height-120);
            g.fillRect(x+10,y-10,width-170, height-150);
            g.fillRect(x+20,y+20,width-170,height-140);

            g.setColor(tan);
            g.fillRect(x+30,y-10,width-180,height-150);
            g.fillRect(x+40,y,width-180,height-120);
            g.fillRect(x,y+40,width-150,height-150);
            g.fillRect(x+80,y+10,width-170,height-150);
            g.fillRect(x+70,y+20,width-180,height-140);
            g.fillRect(x+80,y+40,width-170,height-150);
            g.fillRect(x+100,y+20,width-180,height-140);

            //highlights
            g.setColor(yellow);
            g.fillRect(x+50,y+10,width-170,height-150);
            g.fillRect(x+50,y+20,width-180,height-150);
            g.fillRect(x+110,y+10,width-160,height-150);
            g.fillRect(x+120,y+20,width-170,height-150);
            g.fillRect(x+160,y+10,width-170,height-150);
            g.fillRect(x+70,y-40,width-180,height-140);
        }

	}
	
    public void disappear(){
        visible = false;
    }

    public boolean getVisible(){
        return visible;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y-80;
    }

    public int getWidth(){
        return width;
    }

    public int getHeight(){
        return height;
    }
	
	public void move(){
        x--;
        count++;

        if(yDirection == 1){
            y--;
        } else if(yDirection == 2){
            y++;
        }

        if(count == 50){
            yDirection = (int) (Math.random()*3);
            count = 0;
        }

        if(y <= 80){
            y++;
        }

        if(y >= 520){
            y--;
        }
    }

    public void reset(){
        x = 600;
        visible = true;
    }

    public boolean checkCollision(Ship s){
        boolean collision = false;

        if(visible == true){
            int eX = x;
            int eY = y-80;
            int eWidth = width;
            int eHeight = height;
            int tX = s.getX();
            int tY = s.getY();
            int tWidth = s.getWidth();
            int tHeight = s.getHeight();

            if( eX+eWidth >= tX && eX <= tX + tWidth  &&  eY+eHeight >= tY && eY <= tY + tHeight ){
                System.out.println("Collision");	
                visible = false;
                collision = true;	
            }
        }
        return collision; 

    }
}

